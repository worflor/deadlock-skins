Maid Lash: N°7, Grand Service
=============================

A hero skin for Lash. He is dressed for service: sailor-collar bodice, layered skirt with white and sky-blue
piping, an apron with a red F and a heart, red bows, laced boots, a headdress with ribbons. The whip spool on
his back is worth a look from behind. The outfit has cloth that moves, and Lash's abilities, HUD cards, sounds
and animations carry the same theme.

It changes how Lash looks and sounds. It does not change what he does: no stats, no hitbox tricks, no removed
effects or audio cues. The skirt is wide, so the pak was checked against Valve's own Lash with the Magician
linter (deep, 0 errors); the outline stays inside the limit that tool enforces.

Previews are in previews/. They are screenshots from the game, taken on build 6864.

Quick start
-----------

1. Close Deadlock.
2. Either import this folder into Deadlock Mod Manager (see "Install" below), or copy
   files/0000-maid-lash/pak10_dir.vpk into Deadlock/game/citadel/addons/.
3. Optional, for the hero-roster pose: double-click install-scene.cmd (on Linux or Steam Deck, run install-scene.sh).

What is in this folder
----------------------

- files/0000-maid-lash/pak10_dir.vpk: the skin. Model, materials, cloth, VFX, HUD art, sounds, animations. About
  111 MB. This is the only file the game needs.
- scene/lash/: the hero-page scene, as a patch: only my three files, none of Valve's. About 5.7 MB. See "The
  hero-page scene".
- install-scene.cmd and uninstall-scene.cmd (Windows), install-scene.sh and uninstall-scene.sh (Linux, Steam
  Deck): build and install that scene from your own game files, and remove it. They run install-scene.ps1 (Windows
  PowerShell) or install-scene.py (Python 3). Both are plain text you can read first, and they write the same file.
- mod-interchange.json and mod.config.json: the details mod managers read (name, author, hero, version, files).
- README.md and README.txt: this text. CHANGELOG.md: what changed in each version.
- SHA256SUMS.txt: checksums of every file here.
- previews/: screenshots.

Built for Deadlock build 6864. A game update can break a mod. If Lash looks wrong after a patch, turn this off
and wait for a new version.

Install
-------

Mod manager (Deadlock Mod Manager). In Mods Library, open Add mods, choose Open export file… and pick
mod-interchange.json in this folder. Leave Mods ticked and press Import. It comes in as a local mod (skip the
GameBanana link step if it asks). Tested with Deadlock Mod Manager 2.3.0: import, switching it off and on, and delete
all work. The manager picks the pak number, and it renumbers the other paks in addons to fit. That is normal for it
and harmless. It does not handle the hero-page scene: install that with the script below, and remove it with
uninstall-scene.cmd, because switching the mod off in the manager leaves the scene in place.

By hand.
1. Close Deadlock.
2. Open Deadlock\game\citadel\addons\ (make the folder if it is not there).
3. Copy pak10_dir.vpk into it. The name can be any pakNN_dir.vpk that nothing else in that folder uses
   (01 to 99). If you already have a pak10_dir.vpk, pick a free number and rename the file.
4. Open Deadlock\game\citadel\gameinfo.gi. In the SearchPaths block there must be a line
   Game    citadel/addons above the line Game    citadel. If it is missing, add it. Mod managers do
   this for you. A Steam update puts the file back to stock, so check it after patches.
5. Start the game.

The hero-page scene
-------------------

The pose and lighting Lash gets when you hover him in the hero roster. It is optional; the skin works without it.

A scene is a map file, and most of what is in it is Valve's own compiled map, which I do not hand out. So this folder
carries only my three files (the lights, a shadow card and the showcase model) plus a list of which of Valve's files
the scene keeps. install-scene.ps1, a plain PowerShell script you can read, takes your own copy of Valve's map from
your game, checks it is the one my files were made for, and puts the two together on your machine. Nothing to
download or install; Windows already has PowerShell.

1. Close Deadlock.
2. Windows: double-click install-scene.cmd. Windows may ask whether to run a file from the internet; choose Run.
   (It is a short text file; open it in Notepad first if you like.) If Deadlock is not in a Steam library Steam
   knows about, run it from a terminal with install-scene.cmd -Game "<your Deadlock folder>\game".
3. Linux or Steam Deck (desktop mode): run sh install-scene.sh in a terminal from this folder. It needs python3,
   which SteamOS and most distributions already have. It finds native, Flatpak and Snap Steam; otherwise add
   --game "<your Deadlock folder>/game".

It writes addons\maps\ui\hero_prefabs\lash.vpk and checks the result is byte-for-byte the scene I tested. It never
replaces a scene file that isn't this one (unless you add -Force). The addons line in gameinfo.gi has to be
there for the game to load it; a mod manager or step 4 above adds it. If a game patch has changed Valve's map since I
made this, it says so and installs nothing; the scene then waits for a new version of this download. That is on
purpose: my lights were set for the map as it was.

Uninstall
---------

Delete the pakNN_dir.vpk you copied (or delete the mod in the manager). Run uninstall-scene.cmd (or
uninstall-scene.sh) to remove the scene; the manager does not touch it. Nothing else was changed. You can leave the addons line in gameinfo.gi.

What is not in it
-----------------

- Valve's hero-page map. The scene above is built on your machine from your own copy; none of Valve's files are in
  this download. Mod managers do not install it (it lives in addons\maps\ui\hero_prefabs\), which is why it has its own
  script. Without the scene, the hero page shows Valve's Lash in his stock pose; everything in a match is the skin.
- Everything here is built files. No source files, and no file of Valve's goes in unchanged (every file was
  compared against the game's own at the same path). The sounds and some effects are built on the game's
  recordings and effects, reworked.

Not seen yet
------------

Seen working in a real game (build 6864): the outfit from every side, the cloth, death, knockdown and
get-up, the slide, mantle, all four abilities (Grapple in flight, Ground Strike, Flog, Death Slam), the gun's fire
and reload, and the HUD icons and hero cards.
Not yet seen: melee swings, and a long fight with the skin at distance. The sounds were measured against Valve's
(effects no louder or longer; voice lines run longer because a short stinger follows his last word) but have not
been judged by ear in a match yet.

Version
-------

Version 1.0.0 (build b42), 2026-11-22, game build 6864. Made with Magician, a mod compiler. The skin carries an invisible maker's
mark in its textures.
