# Changelog

Newest first. Each version says which Deadlock build it was tested on.

## 1.0.1 (2026-11-24, build b43, Deadlock build 6865)

- Sharper hero cards and portrait at small sizes.
- Fixed a cloth texture that shimmered at a distance.
- Tested on Deadlock build 6865.

## 1.0.0 (2026-11-22, build b42, Deadlock build 6864)

First release.

- The outfit on Lash's own body: a parlourmaid's livery cut like a sailor uniform, a hooped skirt, a looped-up train,
  lace, bows and laced boots, with cloth on the skirt, train and ribbons.
- Every ability re-dressed (ribbons, doilies, porcelain, rose petals, a cloche), new HUD cards and ability icons,
  86 re-keyed animation clips, and a sound set built from physical models. His voice is untouched.
- A hero-page scene with its own pose and lighting, installed by script from your own game files.
- Cosmetic only: hitboxes, silhouette limits and gameplay cues checked against Valve's Lash.
