@echo off
rem Builds and installs the hero-page scene(s) from your own copy of Deadlock. Needs only Windows PowerShell.
rem Extra arguments go to install-scene.ps1, for example: -Game "D:\SteamLibrary\steamapps\common\Deadlock\game"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-scene.ps1" %*
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
