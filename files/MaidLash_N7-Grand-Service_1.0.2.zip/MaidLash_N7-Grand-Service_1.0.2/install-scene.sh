#!/bin/sh
# Builds and installs the hero-page scene(s) from your own copy of Deadlock (Linux, Steam Deck). Needs python3.
# Extra arguments go to install-scene.py, for example: --game "$HOME/.local/share/Steam/steamapps/common/Deadlock/game"
cd "$(dirname "$0")" || exit 1
exec python3 install-scene.py "$@"
